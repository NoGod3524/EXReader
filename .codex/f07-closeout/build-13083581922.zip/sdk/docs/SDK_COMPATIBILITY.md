# EXReader SDK compatibility

Current development SDK: **3.40.0**, core **3.39.0**, ABI epoch **1**, library
schema **7**. The WP6 checkpoint had 324 named public function exports (316
previous names plus eight chapter-reading functions); later bounded storage
adds further public entry points. That count is historical, not the current
package's complete export inventory. Versioned sections below retain their own
checkpoints; current SDK and native-host evidence is in [R5-SDK-FREEZE.md](R5-SDK-FREEZE.md).

ABI epoch **1** was introduced in development step **S091** (original build
**0.91.0**, commit `7dc8d8a`), now classified as **3.4.0** in the [changelog](../CHANGELOG.md). `EXR_ABI_VERSION` identifies the header's epoch;
`exr_abi_version()` identifies the loaded library's epoch. `EXR_VERSION` and
`exr_version()` identify the release. Epoch 1 does not retroactively classify older
SDK binaries that did not export the ABI query.

## Binary contract

Within one epoch, existing exported C symbols, calling conventions, enum numeric
values, public record sizes/alignment/member offsets, callback signatures and
ownership contracts remain compatible on the same operating system, architecture
and compiler ABI. Removing symbols or changing those layouts requires a new epoch.
Adding functions does not. Codec/algorithm feature gates retain their public symbols;
for example, `exr_text_index_available()` reports whether FTS indexing is enabled.
A host using new functions also requires the release
that first provides them; an epoch alone does not imply that every later symbol
exists in an older library.

Use the platform's normal C calling convention, natural structure alignment and
normal enum representation. Do not compile the public header under packing or
short-enum options. C++ callers use the header's `extern "C"` declarations and keep
exceptions inside their own callbacks. `size_t` and pointers are native-width;
public structs are not an on-disk or network serialization format.

Existing array-element records cannot gain fields within an epoch, including
fields appended at the end: that would change their stride for older callers.
New array layouts require new types and entry points. Inputs explicitly carrying
`struct_size` may grow by preserving the original prefix. Zero-initialize them,
set the size of the header's actual type and leave unused fields zero. A library
rejects unsupported nonzero extensions instead of silently interpreting them.
The original fixed-provider prefix remains a tested consumer even though later
headers append optional text, metadata and annotation callbacks.

The 0.18 development PDF password interface appends `pdf_password`,
`pdf_password_size` and `pdf_security` to `exr_fixed_open_options`; the original
prefix remains accepted. Recompile hosts that need these fields. Error values
0-9 retain their numbers; 10 is `EXR_PASSWORD`, 11 is `EXR_UNSUPPORTED`.
`exr_pdf_security_info` is a new output type with its own `struct_size`.
`exr_pdf_crypto_available()` reports the optional build component. The Swift
initializer adds a defaulted `password: Data?` parameter, and Java retains its
original constructors while adding password-byte overloads and security snapshots.
Rebuild JNI together with its matching Java wrapper. Windows MinGW now installs
`exreader_jni.dll` with the filename expected by `System.loadLibrary`.

The later 0.18 table-layout update defaults to content-driven auto widths,
including shrink-to-content for tables without a definite width. Existing table
page counts and coordinates may therefore change, while source text positions
and public ABI layouts retain their contract. Use standard
`table {table-layout:fixed;width:100%}` CSS for the old full-width equal-column
presentation; unnamed host nodes can carry that inline style directly. The old
0.10 pixel goldens explicitly request this fixed presentation, while independent
auto-width vectors, random tables and checkpoint tests validate the new default.

Cell alignment now uses the CSS baseline initial value and HTML table-group
defaults, with top/middle/bottom/baseline support. Different font sizes/paddings
and spanning cells may therefore change row heights or content coordinates.
Request `vertical-align:top` on cells to preserve the old top-aligned presentation;
the legacy pixel-golden CSS does so explicitly. The first-line/row baseline
metadata remains private; public array strides and ABI epoch stay unchanged.

## Ownership and execution

The Swift adapter adds indexed `EXReaderPager.get(page:)`, returning owned bitmap
bytes and a UTF-8 source range. Do not mix this cached mode with `next()` on the
same pager. The returned snapshot survives later cache eviction. Fixed-document
rendering optionally accepts `maximumDimension`; omitting it retains the existing
scale contract. Native reference hosts use the installed SDK and record host,
runtime, font and output evidence separately.

Opaque handles are released with their matching `*_free`/close function. Allocated
arrays and nested records use their documented typed free routine. Plain returned
allocations use `exr_free`; never free SDK allocations through a host CRT. Borrowed
views expire with their owning handle. Copy a view when it must outlive its owner.
The API documentation specifies retained font, publication/archive and layout
relationships; those rules are part of the contract.

The engine invokes callbacks synchronously and creates no worker threads. Serialize
calls and lifetime changes for a shared mutable handle or shared archive graph.
Callbacks must not free/reenter the active object. Independent object graphs can
run independently. The atomic unique-import operation additionally protects its
lookup/insert transaction; it does not establish unrestricted thread safety for
all book-library operations.

UTF-8 byte offsets in normalized text, raw XML UTF-16 CFI offsets and fixed-page
coordinates are distinct units. Persist portable selectors/CFIs rather than raw
public structs. Rendering and normalization algorithms may improve across releases;
an ABI epoch describes the binary contract, not pixel-identical output. SQLite
schema versions and supported input-format subsets are tracked separately.

## CMake consumers

An installed SDK contains a relocatable config package:

```cmake
find_package(EXReader 3.40.0 EXACT CONFIG REQUIRED)
target_link_libraries(my_host PRIVATE EXReader::exreader)
```

The version renumbering keeps ABI epoch 1 and SQLite schema 6 unchanged. Update
old CMake requirements such as 0.91/0.96 to the new milestone number. Use EXACT
when selecting this SDK: older development packages numbered 0.91–0.100 sort
above 0.18 and must not be selected as supposedly newer compatible packages.
Historical versions are compared through the [version map](VERSIONING.md) and
commit IDs, rather than numeric ordering across the renumbering.

Set `CMAKE_PREFIX_PATH` or `EXReader_DIR` to the selected platform SDK. The imported
target carries its include path and actual platform import/shared-library path;
FreeType, Expat, miniz, SQLite and image decoder build directories are not required
by the consumer. `EXReader_VERSION` and `EXReader_ABI_VERSION` describe that package.
The host bundles the corresponding shared library using its platform's loader
rules. Keep SDK/runtime releases paired unless the host deliberately checks its
required release and ABI at startup.

`examples/compat.c` compares package, header and loaded runtime values. All installed
host examples now use the imported target; desktop CI configures, builds and runs
them independently from the engine source build. Windows copies the installed DLL
next to the examples. Swift and JNI remain separate optional adapters over the
same C contract.


The collapse CSS option adds `EXR_BOX_BORDER` (mask value 2) on block rectangles without
changing the exr_box layout, ABI epoch or library schema. Custom renderers must
preserve these flags and batch each contiguous same-node border run as one RGBA
layer, replacing rectangle pixels within the layer before one source-over blend.
Painting each translucent rectangle independently darkens junctions. Native and
positioned renderers implement the same grouping. Older hosts can request
`table {border-collapse:separate}` until their renderer handles the new flag.
Only the existing uniform solid/none/hidden border subset is implemented here;
side-specific and additional border styles remain pending.


The float update keeps the C/Swift/JNI record layouts and ABI unchanged, but
reflows documents that declare float/clear. Bookmarks remain source selectors or
CFIs. A page's start/end is now a source envelope that can overlap another page:
a float can stay on one page while earlier large text is carried to the next.
Do not infer a unique page from disjoint interval assumptions. Use
exr_layout_page_at for actual source placement; overlapping layouts consult
actual glyph ranges while ordinary layouts retain binary lookup. Positioned
reconstruction now permits overlapping and nonmonotonic-start envelopes with
per-page containment validation. Public inline clips remain authoritative for
indivisible advances and trailing spaces. Installed JNI/Swift smoke includes a
shared original image and long-float EPUBs, checking geometry/pixels and all
7,500 letters through EOF. Long text/table floats now retain independent page
cursors, including nested floats and fixed orthogonal viewports. Ordinary tables
now establish an independent BFC beside external floats: columns are fixed after
the first committed fragment, while each new page selects a fitting rectangle.
Width/padding percentages use the original containing block. Clear waits for
matching continuations. The installed float-bfc-stream.epub smoke counts 3,350
letters and verifies table coordinates through EOF. Tables without external floats
keep their existing pagination path. Unbreakable table row groups still must fit a
page. Checkpoint cloning owns and budgets all pending continuation contexts;
no public record size, ABI epoch or schema changes.


The optional exr_hyphenator adds standalone C provider/pattern-query functions.
Existing layout_config, glyph and pager structures are unchanged, ABI epoch 1
and schema 6 remain. Host callback ownership transfers only on successful
create. Native pattern objects own their packed trie and language keys; source
buffers can be released after create. Context lifetimes are serialized, with
reentry rejected. Native UTF-8 byte offsets refer to the original word even
when Unicode full case folding expands characters. The installed C example is
built/run independently by desktop CI. No language data or new binary dependency
is shipped. This step does not enable automatic hyphens in any layout; pager,
session, CSS and Swift/JNI integration are subsequent work.

Automatic dictionary hyphenation is now opt-in through
exr_layout_create_hyphenated, exr_pager_set_hyphenator and
exr_session_set_hyphenator. Set the pager dictionary before choosing cache or
sequential access mode; changing the session dictionary clears its borrowed
chapter cache. Objects retain the dictionary, while completed layouts contain
only resolved glyphs. Existing layout_config/glyph record sizes, ABI epoch 1
and schema 6 remain unchanged. EXR_GLYPH_GENERATED marks synthetic text; an
independent generated hyphen has an empty source range at its original UTF-8
break point. A font-created cluster containing source and generated text can
retain a nonempty range. Consumers must preserve this flag in snapshots and
positioned reconstruction; selection/copy use source text, not generated glyph
characters. Swift/JNI install dictionaries independently per pager before next.
No language dictionaries are bundled; pattern format limits and separate data
licenses still apply.

Native pattern matching now canonicalizes both patterns and words using Unicode
17 NFC -> full fold -> NFC. This deliberately adds break matches for canonically
equivalent spellings (e.g. decomposed accents). The original document and provider
callback bytes remain unchanged. Grapheme minima and returned offsets still use
original text; folded/decomposed interiors never become new source positions.
A canonically merged pattern preserves max-weight conflict resolution. Consumers
need no record/ABI/schema migration. The separately versioned Unicode 3.2 PDF
password preparation is unchanged.

Native UTF-8 pattern input now accepts two NEXTLEVEL rule sets, compound minima
and NOHYPHEN. No record size, ABI or schema change. Input left/right minima
continue to override whole-word minima, while component defaults come from the
file. File global minima of zero now consistently select the format default 2.
Without NEXTLEVEL, ordinary rules use implicit hyphen/apostrophe/en-dash/curly
apostrophe segmentation and suppression; this deliberately changes matching
of compound tokens. A file without NEXTLEVEL supplies the ordinary level;
its NOHYPHEN field does not replace the implicit layer's defaults. Use explicit
NEXTLEVEL to customize whole-word suppression. Inline gathering retains internal joiners,
so providers also see complete compound tokens. Original bytes and source
positions are unchanged. Structural segmentation may use protected punctuation,
but final visible opportunities still obey GLUE/grapheme protection. Native
matching enforces inward minima even for short leaves. The original provider
bitmap cannot express replacement text; the following query API adds that data.


Discretionary replacements add new C records/functions without changing existing
record sizes, callbacks, ABI epoch 1 or schema 6. exr_hyphenator_query returns an
owned immutable exr_hyphenation; all strings remain valid until result free,
independently of source/dictionary/provider lifetimes. The new discretionary
provider emits synchronously into a copying sink; sink errors are latched even
when ignored by a provider. Original bitmap providers remain supported.

Native dictionaries now accept pattern/before=after[,start,cut]. Malformed
ranges are EXR_FORMAT, not silently truncated. Explicit cut=0 is insertion;
replacement strings are literal by default; the explicit case policy is described below. Equal-weight plain
rules win over rewrites; conflicting equal-weight rewrites suppress the point.
The old breaks API intentionally omits spelling-changing opportunities. Layout
now selects the richer query when needed, including Swift/JNI pagers. Conditional
compound rewriting remains pending. Changed word remainders now receive fresh mapped queries. The installed C example exercises both APIs. An unsupported
raw TeX command now checks failed installation in Swift/JNI smoke, rather than
using slash as an unsupported token after slash grammar became supported.


Layout now renders discretionary before/after strings and includes them in final
shaping/width measurement. Generated glyph source ranges may be nonempty and
cover the replaced original text; do not discard them from hit/range mappings
or copy their characters into source text. Expansion sides retain protected source
selection ranges independently of display grapheme identity. Empty right-side deletions retain an invisible generated source span.
Strings remain literal and inherit their original side's style; display bidi
resolution is described below.
Internal U+00B7 now stays inside gathered words, including host-provider input.

Pending edits and cached word edits are deep-copied with pager checkpoints and
counted against line/checkpoint payload budgets. The three glyph buffers plus
owned word/edit capacities share the 16 MiB line budget. Existing public record
sizes, ABI epoch 1 and schema 6 are unchanged. After each committed replacement,
stale original dictionary bits are cleared and the actual display remainder is
queried again. Fresh ordinary/replacement opportunities must align with protected
display grapheme/GLUE boundaries, preserve original graphemes and advance display positions. Multiple generated points may share a source offset. Erase ranges may
start within a generated side; private raw indices preserve the exact display
range. Candidates whose left context was consumed by an ordinary break are
dropped with their automatic bit. Generated sides remain atomic to selection.
Derived tokens exceeding 256 scalars/1024 bytes use ordinary/emergency fallback.
Future edit context and generated-side wrapping are covered by the supplements below; the explicit Unicode case policy is described below. Installed Swift/JNI smoke now
checks actual replacement glyphs with nonempty original source intervals.

A zero-cut after insertion shares its source cluster with the following original
grapheme. Its glyph start/end may remain empty, while cluster_end includes that
grapheme. This preserves cursor access while display graphemes wrap a long inserted
side across lines and pages.

Display boundaries now replay Unicode 17 grapheme/line state for replacement
sides and the complete queued carry, including pending input. New joins can
widen cluster_start/end across original source positions (e.g. generated RI plus
original RI); they never expose positions within an original grapheme or generated
side. A cluster crossing ready/pending is deferred intact before remeasurement.
Format controls/selectors are hidden normally. Empty deletions have a distinct
private flag, omitted from public output, and do not enter Unicode/dictionary input.
Snapshots include all display states by value; no public record/API size changed.
Conditional compounds remain open; future
context verification is described in the following supplement.


### Display bidi after discretionary spelling changes (0.18 development)

Generated strings now participate in a mapped display analysis before shaping
and final visual ordering; mixed-direction visual subruns retain the original
source selection range, with direction-specific hit endpoints. No public record
size, symbol contract, ABI epoch or library schema changes. Private virtual
indices/flags never appear in installed SDK snapshots. Immutable history and
AUTO paragraph-base records survive checkpoints; ephemeral bidi views are rebuilt.
AUTO preflight ignores isolate contents and preserves current page/float geometry.
Its bounded two-base retry reports EXR_LIMIT for non-converging discretionary
layout. Providers must be deterministic and can be queried during preflight.
Installed JNI/Swift consumers verify actual Latin/Arabic/Han levels, source hits,
and leading neutral pages whose base changes after a later replacement.
Conditional compounds remain
open; future neutral/bracket context now uses the following proposal supplement.


### Stable display proposals across future edits (0.18 development)

Future spelling edits now participate before an affected row is published.
Risky contexts collect mapped display proposals and line boundaries, then replay
with that complete analysis before shaping. Acceptance requires every selected
line to match its proposal and both text/source mapping and line breaks to stay
unchanged. Up to eight proposals are allowed (EXR_LIMIT on non-convergence).
Formal replay rejects a changed provider/proposal with EXR_FORMAT before caching
the failed page. Deterministic providers can receive repeated queries.
Safe bidi boundaries keep ordinary mixed text bounded; actual preceding strong/
weak context is retained, and ES/CS/ET, NSM, brackets, controls and independent
AUTO B paragraphs are handled explicitly. Plans/prefixes count against the
16 MiB line/checkpoint payload; a 24 MiB temporary collector and ~64 MiB view cap
remain separate. Rebuilt views and shared immutable original bidi analyses avoid
copying complete text into every cursor/checkpoint. Copy/analysis work is charged
to the common work budget. No public API/record/ABI/schema changes.
JNI/Swift smoke verifies page-one plus signs at RTL level 1 even though the later
replacement that determines them is not on that page. Generated-side breaks and
explicit Unicode casing are covered below; conditional compounds, tall table-row
fragmentation and the broader VERSIONING.md roadmap remain open.


### Generated-side wrapping (0.18 development)

Transient grapheme identities separate display consumption from original source
affiliation. Committed after strings wrap with Unicode/ordinary dictionary and
emergency opportunities; their words can receive further spelling rewrites.
Mapped raw indices distinguish multiple edits at one source byte point. Original
selection ranges remain protected; no positions inside generated text become
original offsets. Public flags/boundaries contain no transient identities.
Before text plus the inserted hyphen remains a fitting left-line candidate: an
oversized unselected before string uses the existing original-text fallback.

Only private line-buffer state changes; installed record sizes, symbols, ABI 1
and schema 6 stay unchanged. Identities are copied in checkpoints, bounded and
charged through the existing glyph buffers; no parallel identity allocation or
new dependency is introduced. Original source affiliation can span more than one
page, including zero-cut insertions attached to the following original grapheme.

Pure-L insertion between adjacent L display scalars preserves strong context and
uses the existing fast path. Empty generated ranges refer to their following
original L anchor; other cases keep display proposal/analysis. The 1 MiB selected
and unselected insertion regression checks that ordinary text avoids repeated
whole-paragraph work without raising resource limits.


### Explicit native dictionary case policy (0.18 development)

The additive `exr_hyphenator_create_patterns_ex` symbol accepts LITERAL or WORD.
The legacy C constructor and existing Swift/JNI methods preserve literal behavior.
No public record size, ABI epoch (1), schema (6) or version change. The old JNI
native entry point remains present; a distinct entry point handles the explicit
policy, so older compiled Java consumers keep their calling contract. Providers
continue receiving original bytes and emitting literal discretionary strings.

WORD classifies original cased characters and applies Unicode 17 full mappings
to uniform lower/upper or initial-title words; mixed/uncased words remain literal.
Logical changed-word context includes unchanged prefix/suffix and both generated
sides, excluding the display hyphen. Standard Final_Sigma and tr/az/lt conditional
rules are included. Title preservation can extend end through an original retained
grapheme when moving/deleting the original initial; point is unchanged. Respect
the returned source ranges instead of assuming the dictionary cut stayed fixed.
Additional CLDR lexical tailoring can be supplied by host providers.

Generated text still shares the 128-scalar/512-byte cap, work/result budgets and
original selection affiliation. Case-sensitive display proposals, Unicode/shape
state, subsequent rematching and checkpoints use the existing common pipeline.
The compiled Unicode tables add no runtime component or dictionary download.
Installed C/C++ examples and two-page Swift/JNI smoke use the new policy while
retaining the preceding literal smoke checks.

Original inline window safety is classified once on demand in a cursor-local
cache; shared original bidi arrays remain immutable. Ordinary opens do not
classify this additional property. Temporary unmatched candidates can retain an accepted safe display
suffix instead of rescanning the whole source paragraph. Checkpoints rebuild
original safety and preserve the existing display prefix. The 1 MiB combining-
mark regression checks forward access, eviction, pixel-stable rewind and restored
checkpoints; work caps are unchanged.


Conditional compound stem reconstruction uses the existing C query/bitmap and
Swift/JNI pager calls. An explicit NEXTLEVEL dictionary can restore a left stem
for recursive matching without editing the original document. Only mapped whole
source intervals are returned; generated spelling has no invented interior source
positions. Only taking the corresponding line break applies its substitution.
Source grapheme minima, literal/WORD policy, 128-scalar/512-byte public result cap,
ABI 1 and schema 6 stay unchanged. Per-query conditional matching workspace and
owned stem strings are capped at 1 MiB. Installed C/C++ consumers verify recursive
breaks 2/4/7/9; Swift/JNI smoke checks the newly enabled source break on a real EPUB.


Tall table rows and connected rowspan groups now retain independent cell flow
cursors. Full lines/images cross pages without a shared canvas crop. Cell/grid
state and nested cursor allocations participate in checkpoint cloning and byte
accounting. Multi-column pages can overlap in their original source envelopes;
use actual glyph/cluster ranges for selection. The 128-float tree limit includes
cell cursors. Public C/Swift/JNI calls, record sizes, ABI 1 and schema 6 remain
compatible. Installed examples include a tall rowspan EPUB and use existing
pager calls; C++ also verifies checkpoint-based backward access.

Top/baseline groups probe one page before committing a tall row. Middle/bottom
alignment still needs full-height measurement, and auto-width tables still scan
full min/max-content input. Large-cell cost differences are recorded separately;
the performance report lists fixed, automatic and bottom-aligned costs separately.


RGB compositing adds size-tagged `exr_draw_sink_ex` and an optional `draw_ex`
tail to size-tagged `exr_fixed_input`. The original unversioned sink and fixed
render options keep their layouts. Existing providers still supply `draw`;
`exr_fixed_draw_ex` falls back to it with `sink.base`. Original annotation-capable
input prefixes remain accepted and have a compile-time ABI assertion.

For a host renderer, initialize `sink.struct_size`, retain the original callbacks
in `base`, and add blend plus paired begin/end layer callbacks. All callbacks use
`base.context`. A successful begin must be matched by end; commit=0 unwinds and
discards. A valid end consumes its layer even when reporting an error. PDF blend
consumers need the pair for isolated page content and Form/AP groups. The original
PDF draw entry rejects actual non-Normal blend paints and isolated Form groups.
Inspection consumers may skip primitives, but must acknowledge requested effects.

For built-in rendering no host migration is needed. Gray PDF output now uses an
RGB working image and converts at the end, subject to the existing 64 MiB RGB
bitmap ceiling. Isolated layers have a separate 64 MiB aggregate pixel budget;
combined fill/stroke uses two coverage masks charged to mask_budget. Callers
using a canvas directly can set the layer budget before entering layers. Layer
budget failure, cancellation or unbalanced scopes never returns a partial bitmap.
This is still 0.18.0 development, ABI 1 and schema 6.


Non-isolated RGB groups append optional `begin_group` to the size-tagged
`exr_draw_sink_ex`; all earlier prefixes remain accepted. Initialize the new
struct_size when recompiling. General begin is preferred; isolated requests
fall back to begin_layer, while non-isolated requests on an old consumer return
EXR_UNSUPPORTED. Either begin callback requires end_layer. The original sink,
fixed render options, ABI 1 and schema 6 retain their layouts/contracts.

Direct canvases can use exr_canvas_begin_group with flags=0 or
EXR_GROUP_ISOLATED, closing either with end_layer. Non-isolated groups reserve
24 bytes/pixel (RGBA8 plus five float channels), versus 4 for isolated layers;
both count against the aggregate 64 MiB default and the per-group 64 MiB cap.
The precision state remains private and is heap-stable across layer-stack growth.
No additional runtime component is introduced. The PDF Form/AP default I=false
now renders as non-isolated RGB; explicit CS on a non-isolated Form is malformed.
Knockout groups and graphics-state soft masks remain pending.

## Independent border sides and repeated table headers

`border-top/right/bottom/left` (width, colour and style) now reach blocks,
separate cells and collapsed grids. Uniform four-sided borders keep using
`exr_box.border_width`, `exr_box.border_color` and the DASHED/DOTTED/DOUBLE
flags, so existing drawing code is unchanged. When the four sides differ, the
layout appends one `EXR_BOX_BORDER` box per visible side instead of setting
`exr_box.border_width`; hosts that already paint collapsed-table border layers
handle them, while a host that only reads `border_width` must also draw border
boxes. No public record size, member offset, symbol, ABI epoch (1), schema (6) or
version changes. Table pagination also repeats leading `<thead>` rows at the top
of each continuation page; the extra repeated glyphs and boxes carry the header
source offsets.
## Mesh shadings 6/7 and DeviceCMYK groups

PDF mesh shadings types 6 (Coons patch) and 7 (tensor-product patch) now render
through the existing shading callback with the same bitmap-plus-matrix contract;
no callback or record changes. Transparency groups whose `/CS` is `DeviceCMYK`
are accepted: colours are converted with the engine's naive DeviceCMYK model and
the group composites in device RGB, so opaque content matches a CMYK-space
renderer but translucent overlaps may differ. Radial shadings with `/Extend`
now paint their extended colour into larger clips (a finite one-span margin per
side, like the axial path). No public symbol, record size, ABI epoch (1), schema
(6) or version changes.
## Canvas DeviceCMYK groups

`EXR_GROUP_CMYK` and `exr_canvas_path_cmyk` are additive: ABI epoch 1, schema 6
and the package version stay put. `exr_draw_sink_ex` gained one appended
`path_cmyk` callback; hosts that initialize `struct_size` to their own (older)
size keep working and simply leave it NULL. The canvas sink implements it, so PDF
DeviceCMYK groups now carry source components into the four-component buffer;
nested groups inherit the blend space and compound fill+stroke paths composite as
one CMYK element. Non-separable blend modes inside a CMYK group return
`EXR_UNSUPPORTED` instead of approximating.
## Historical package version 3.33.1

At this checkpoint, the tree, header and installed config package reported
**3.33.1** development. ABI epoch 1 and library schema 6 were unchanged: no exported
symbol, record layout, enum value or callback signature moved with this
renumbering. The complete historical size-based reclassification is in the
[changelog](../CHANGELOG.md); the previous 0.20.0 component split is now 3.33.0.
Select the current package with `find_package(EXReader 3.40.0 EXACT
CONFIG REQUIRED)`. The 0.18.0 records (code commit `ec8d4a98`, DLL SHA-256,
CI run 39148719500 and the benchmark samples) keep their original number.

## 0.19.0 rendering corrections and license

The original EXReader code and fixtures now use MIT. Third-party notices retain
their own terms. Default and CI builds exclude FAAD2; explicitly enabling that
GPL codec produces a linked binary that cannot be distributed under MIT alone.
Existing releases retain the permissions already granted with them.

With ICC enabled, DeviceCMYK uses the complete bundled Argyll fallback profile;
ICC-disabled builds retain the documented simple device conversion. CMYK group
buffers blend native components, including subtractive separable and nonseparable
mode formulas. Earlier descriptions of RGB-only group blending and rejection of
all nonseparable CMYK modes above describe previous checkpoints. Images and
shadings still pass through RGBA in CMYK groups, losing original separations.
The 3.33.1 correction below supersedes the explicit RGB child issue.

Shading opacity, blend and soft masks now reach the painter, mesh interpolation
precedes color conversion, and Matte is undone before ICC conversion. These
corrections change affected pixels without changing public record layouts,
symbols, callback signatures, ABI1 or schema6. See AUDIT-2026-10-19.md for scope.

## Component linkage

`exreader.h` remains the full declaration umbrella. `exr/core.h` includes only the
reading core; the other public headers can each be included independently in C
and C++. The default compatibility shared library retains all 304 existing
exports. Static component consumers link `EXReader::exr_core`, `exr_audio`,
`exr_library`, `exr_pdf`, `exr_pdf_edit` or `exr_textindex`; these targets propagate
`EXR_STATIC` automatically. Choose either the compatibility shared library or the
static components within one process, so object ownership stays in one instance.

Component removal is an explicit build profile: an omitted library has no binary
or exported entry points in that profile. This differs from disabling a codec
inside an included component (for example AAC OFF still exposes the documented
unavailable-codec functions). Hosts discover installed components with CMake
`find_package(EXReader CONFIG REQUIRED COMPONENTS core audio)`; absent required
components fail configuration. The standard full build remains the ABI1
compatibility artifact.

Core and optional component release numbers are maintained in
`cmake/versions.cmake` and exposed by the corresponding public version macros and
installed CMake target `EXR_COMPONENT_VERSION` properties. Core and PDF reading are 3.34.0; the other components remain 3.33.0
after this fix and can be released independently. Release
numbers follow update size: very large updates increment the major number,
medium updates increment the minor number, and small bug fixes increment the
patch number. Incrementing major or minor resets the following numbers to zero.
ABI compatibility is tracked separately: this split preserves ABI1 core
signatures, records and ownership rules.

Static Windows components use the same MSVC runtime setting as the SDK build
(default `/MT`, `/MTd` for Debug). The installed component consumer examples use
that setting explicitly.

## 3.33.1 group colour spaces and knockout flags

PDF group `/K true` now enables knockout; false, null or omission selects a
normal group. Earlier implementation and fixture generation inverted this flag.
The 50-scene PDF inputs have been regenerated with the correct literal flags;
the independent Decimal pixel references and existing error tolerances remain.
Affected PDFs can change pixels while the public ABI remains epoch 1.

`EXR_GROUP_RGB` explicitly selects RGB in an isolated Gray/CMYK parent. An omitted
colour-space flag still inherits. `exr_canvas_begin_layer` follows its documented
isolated RGB contract. Child output converts at group commit, then group opacity,
blend and clipping apply in the parent's space. Parent native inks and space are
restored on both commit and discard. Conflicting space flags are invalid; switching
to RGB from Gray/CMYK without isolation is unsupported. PDF non-isolated forms with
an explicit `/CS` remain invalid under the existing contract. A custom `begin_group`
consumer must honour the RGB flag or reject it; legacy `begin_layer` supports the
isolated RGB fallback. No function signatures, exported symbols or record layouts
change. Images and shadings still lose original ink separations through RGBA at
that checkpoint; the following update supplies a native path.

## 3.34.0 native image separations

`exr_canvas_image_cmyk` borrows a CMYK byte bitmap and an unchanged
`exr_image_layer`. The layer supplies the RGB fallback, source alpha, interpolation
and masks; native inks must already be un-matted. The bitmap has four C/M/Y/K
bytes per pixel, matching the layer dimensions. CMYK groups sample and blend the
inks; other spaces use the supplied RGB fallback.

`exr_draw_sink_ex` appends optional `image_cmyk` and `image_space` callbacks.
The original prefix and existing signatures stay unchanged. The canvas requests
inks only in an active CMYK group, so RGB pages allocate no extra ink buffer.
A custom consumer without the query requests inks whenever it supplies
`image_cmyk`. That callback also receives CMYK gradients as an interpolated layer.
Wrapping consumers must forward both callbacks with the target's context.

DeviceCMYK PDF images retain samples after Decode and Matte removal, before RGB
conversion, including JPEG and image/color-key masks. Shadings 2–7 retain evaluated
or interpolated ink values. Samples are quantized to 8 bits before interpolation.
ICCBased/DeviceN conversion to CMYK groups and document OutputIntent remain separate
matrix items. The existing 128 MiB image/mask pixel ceiling includes the native
buffer. One exported function is added; the previous 304 exports remain. ABI1
and schema6 stay unchanged; core and PDF reading are version 3.34.0.


## 3.34.1 nested group corrections

Knockout groups now track group-only alpha separately from the initial backdrop,
including compound paths and nested group commits. Non-isolated child output
removes the backdrop actually used to paint it, and children of knockout parents
start with that parent's initial backdrop. Nested region origins are accumulated
when referring to an ancestor backdrop. Clipping can reduce nested Form and
appearance buffers; empty clips use a 1×1 working buffer. Affected pixels and
resource-limit outcomes can change. Public layouts and symbols are unchanged from
3.34.0, ABI1/schema6 remain; core/PDF reading are 3.34.1.

128 new nested scenes match Decimal probes within 1/255; independent MuPDF
low-alpha differences remain recorded, and soft-mask/AIS/group-shape auditing
continues. This correction is not a claim of full PDF transparency conformance.


## 3.34.2 mask scope corrections

No public function or record layout changes. Transparency groups suspend the parent
soft mask and restore it for the single group commit. Internal shape tracking is
allocated only when required by a knockout or shape-tracked parent. Active PDF
soft masks have a 64 MiB aggregate limit; nested masks share the operation budget.
Core/PDF reading are 3.34.2; other component versions remain 3.33.0, ABI1/schema6.

## 3.36.0 alpha source extension

`exr_draw_sink_ex` appends `alpha_source(context, flags, error)`. Its size is
136 bytes on the verified Windows x64 ABI; the previous 128-byte prefix remains
accepted, all old offsets and unversioned records stay unchanged, and the DLL
still exports 305 functions. ABI1/schema6 remain; core/PDF reading are 3.36.0.

`EXR_ALPHA_CONSTANT_SHAPE` interprets primitive/group alpha constants and the
current graphics-state soft mask as shape rather than opacity. `EXR_ALPHA_IMAGE_SHAPE`
interprets bitmap alpha as intrinsic image shape; explicit image masks always
constrain shape. Soft image masks follow the constant-shape setting. Save/restore
and group scopes preserve the flags, while group interiors start with default
flags and receive the state of their own primitives. Wrapping sinks must forward
the callback through their own context, just like the existing effect callbacks.

Missing callbacks retain the older image interpretation and reject requested
constant-shape semantics with `EXR_UNSUPPORTED`. Nonzero truncated pointers and
unknown canvas flags are rejected. Callback error values are propagated even
when a callback returns success. No new pixel plane is allocated; the measured
one-pixel canvas payload increases by 648 bytes for fixed state.

## 3.37.0 PDF component update

The SDK version and `exr_version()` are 3.37.0; the PDF component is 3.37.0,
the unchanged core component remains 3.36.2, and other components remain 3.33.0.
Public signatures, the 703 measured ABI properties and 305 exports stay unchanged.
Type 1 two-input function shadings and per-component function arrays reuse the
existing bounded evaluator. Array children share one 1 MiB/16-level/1024-node
graph budget; their evaluation costs accumulate in the shared drawing budget.
Type 1 currently uses a 512×512 bitmap, with an additional same-size ink bitmap
only for native CMYK consumers. Complete Extend and adaptive sampling remain pending.


## 3.37.1 zero-opacity correction

The SDK/PDF versions are 3.37.1; the core component is 3.36.3. ABI1/schema6, public signatures and record layouts remain unchanged.
A zero-opacity primitive or subgroup retains its geometric shape when a knockout or shape-tracked parent needs it. Constant-shape zero and intrinsic zero shape remain no-ops. This corrects earlier path/image/CMYK/group inconsistencies; see MASK_SEMANTICS.md for the ISO mapping and external-renderer differences.

## 3.38.0 procedural paint sources

The core component is 3.37.0 and the SDK/PDF components are 3.38.0.
`exr_canvas_paint` synchronously consumes a size-tagged `exr_paint_source`.
Its sampler receives source coordinates, the requested RGB/CMYK blend space,
and separate component, shape and opacity outputs. The transform maps source
coordinates to the complete canvas, including inside a cropped working group.
The source owns its context; the canvas retains no source pointers after return.
Callbacks must not mutate the active canvas. A failing callback, a success return
with a nonzero error, invalid samples, cancellation and exhausted work budget
all fail the draw and prevent taking partial output.

The canvas averages four subpixel samples per pixel, weighting straight colours
by source alpha. Clip coverage, constant alpha, soft masks, AIS and knockout
composition reuse the existing pixel writer. No temporary pixel plane is added.
The callback's own work and memory must be bounded by its provider.

`exr_draw_sink_ex` appends `paint`; its Windows x64 size grows from 136 to 144
bytes while all earlier offsets and prefixes remain valid. The source record is
24 bytes on that ABI. Wrapping consumers must forward the callback through their
own context. A missing `paint` retains the existing bounded bitmap shading path;
hosts must implement this callback to obtain clip-wide axial/radial extension.

The native PDF painter uses a 512-entry RGB colour table (12,288 bytes), plus a
2,048-byte ink table when a CMYK consumer requests it, instead of a 512×512 radial
bitmap. Geometry is evaluated at actual device samples through the full clip;
colour functions and ICC are evaluated once per table entry. Type 1 and mesh
shadings retain their bitmap paths. Fixed colour-table resolution is still a
limit for sharply varying functions; adaptive sampling remains pending.
The new export is additive; ABI epoch 1 and schema 6 remain unchanged.

## 3.38.2 table measurement and corpus diagnostics

The SDK is 3.38.2 and the core is 3.37.2; PDF remains 3.38.1.
ABI1/schema6 and all public layouts and signatures remain unchanged.
Plain horizontal Latin table cells can measure min/max content in one bounded
scan when their fonts require no OpenType shaping. Rich content, other scripts,
bitmap fonts and ambiguous whitespace retain the existing general algorithm.
The optimization does not implement incremental chapter parsing.
Corpus diagnostics retain baseline expectations and never grant acceptance.
Their independent PDF probe is an optional validation tool, not an SDK dependency.

## 3.38.3 chapter input chunks

SDK3.38.3/core3.37.3 retain ABI1/schema6; PDF remains 3.38.1.
EPUB chapter extraction feeds the existing XML tree through bounded input calls.
The complete document tree, normalized text, borrowed-view lifetime and public
signatures remain unchanged. Hosts need no migration; rebuild and select the
new exact package version as shown above. The 32 MiB ZIP member and 128 MiB
aggregate expansion limits are unchanged. This removes an extraction copy;
it does not provide a bounded chapter window or random-access chapter parser.
The installed SDK now includes `docs/SUPPORT_MATRIX.md`; component-consumer
configuration rejects a package that omits it. Existing binaries and ABI are
unchanged by this packaging correction.

## 3.39.0 declared WP7 scripts

SDK3.39.0/core3.38.0 add Bengali, Tamil, Telugu, Kannada, Malayalam, Thai,
Khmer and Myanmar shaping; PDF remains 3.38.1. ABI1/schema6 and public layouts,
signatures and ownership remain unchanged. Rebuild and select the new exact SDK
version shown above; no host API migration is required.
The fixed oracle has 50 sequences per script against real and synthetic fonts
(800 cases), HarfBuzz14.6.0, exact glyph IDs, cluster containment and fixed
1.5 px metric tolerance at 200 px. HarfBuzz is not a runtime dependency.
Scope and boundaries are in the installed `docs/WP7-SCRIPTS.md`. Test fonts are
not installed; their OFL notice is included under `share/exreader/licenses/wp7-fonts`.

## COLR v1 and SVG fonts (WP8)

`exr_font_color_info_get()` is a new export and
`exr_font_color_info` is a new size-tagged output record. Existing
`exr_font_color_layers()`, `exr_font_glyph_image()`, glyph records and all
callback signatures keep their layouts. Callers initialize
`struct_size = sizeof(exr_font_color_info)`; smaller records are rejected and
unknown nonzero trailing bytes are refused. The function changes per-face
palette caches like the other colour-font queries, so the existing font
serialization rule applies. ABI epoch 1 and schema 6 are unchanged; mainline
ships this additive API in SDK3.39.0/core3.38.0 alongside controlled export.

The built-in renderer now paints COLR v1 before COLR v0 and paints an SVG
font document when the face has no COLR v1 glyph. sbix/CBDT strikes still win.
The COLR v1 subset covers paint formats 1–32 with the limits, composite subset
and variable-paint delegation documented in
[WP8_COLR_V1.md](WP8_COLR_V1.md). Unsupported paint formats, unsupported
Porter-Duff composite modes, malformed palette/stop data and the declared
size/depth/node limits return `EXR_UNSUPPORTED`/`EXR_FONT`/`EXR_LIMIT`;
they never produce partial pixels. The text foreground alpha is applied once
when the completed glyph surface is composited, and palette index 0xffff keeps
the COLR v0 foreground rule.

SVG-in-OpenType is a frozen subset implemented in-tree; no new runtime
component is linked (gzip documents reuse the existing miniz, and the XML
reader rejects DTDs, entities, scripts and external references instead of
fetching them). The element/attribute/rejection matrix and coordinate mapping
are in [WP8_SVG_FONTS.md](WP8_SVG_FONTS.md). Both features keep the glyph
advance, source clusters, bidi levels and hit-test results unchanged; only
intrinsic colour pixels are added. Registrations for `native-font-color-v1`
and `native-font-svg` accompany the existing `native-font-color` run.

## 3.39.0 lightweight conversion

`exr_document_export_control()` adds cooperative cancellation to the existing
text-profile exporter. `exr_document_export()` delegates with a NULL control;
existing signatures, ownership and public layouts remain unchanged. New callers
must select SDK3.39.0 or later. Installed `docs/CONVERSION.md` defines profiles,
format aliases, cancellation granularity, CLI publication and report semantics.
`exreader-convert` is installed when tools are enabled. Core-only builds retain
the public export API; the CLI is tested through the installed default SDK.

## 3.39.0 WP12a image codecs and streaming library imports

Mainline assigns SDK3.39.0/core3.38.0, PDF3.38.2 and library3.34.0; ABI epoch 1 and library schema 6 remain unchanged.
It adds symbols; it does not change any existing exported signature, enum value,
record layout or callback contract.

The image entry points remain:
`exr_image_decode()` (page 0), plus new `exr_image_page_count()`,
`exr_image_page_dimensions()` and `exr_image_decode_page()`. PNG/JPEG/BMP/GIF
are built in; WebP/TIFF/AVIF are default-on build options
(`EXR_ENABLE_IMAGE_WEBP/TIFF/AVIF`). A disabled codec returns
`EXR_UNSUPPORTED` and keeps the symbols. Multi-frame GIF/WebP/AVIF and
multi-directory TIFF expand in source order; CBZ page IDs for existing
single-page PNG/JPEG files are unchanged. See [WP12A-FORMATS.md](WP12A-FORMATS.md).

The library adds source-based imports:
`exr_library_import_source()`, `exr_library_import_source_unique()`,
`exr_library_import_file()`, `exr_library_import_file_unique()` and
`exr_library_fixed_source()`. The source is borrowed for the call; CBZ bytes
are copied into SQLite in 64 KiB chunks. `import_file` also accepts PDF,
parsing metadata through a read-only file mapping. `exr_library_fixed_source()`
reads a stored CBZ through SQLite blob I/O and pages a stored PDF into an
anonymous pagefile mapping before parsing. A single stored original is limited
to 2 GiB - 1 by the blob API and `SQLITE_MAX_LENGTH` (raised from the 1e9
default to INT_MAX). Other formats keep the existing in-memory APIs and
streaming entry points return `EXR_UNSUPPORTED`. See [WP12A-STREAMING.md](WP12A-STREAMING.md).

Contract notes for hosts:

- `exr_image_decode()` returns page 0; a page index at or beyond the count
  returns `EXR_LIMIT` with a zeroed bitmap. Damaged input is `EXR_FORMAT`;
  a build-time disabled codec is `EXR_UNSUPPORTED`.
- Multi-page CBZ labels are `<member>` for frame 0 and `<member>#N` for later
  frames. Existing single-page IDs, natural ordering and ComicInfo remain.
- Streaming imports keep the existing unique-import serialization and
  exact-byte dedup. Failure or cancellation rolls back both row and blob.
- The installed package exports each codec's static libraries as private
  `EXReader::vendor_*` targets; the legacy shared `EXReader::exreader` remains
  the compatibility artifact. Configuring with all three codec options OFF
  still installs and consumes normally.

## 3.39.1 audited image, CBZ and SVG corrections

SDK3.39.1/core3.38.1/PDF3.38.3 correct failure cleanup, source short-read retries,
member-before-frame ordering, TIFF straight RGBA output and SVG stroke/opacity defaults.
TIFF normalizes libtiff's associated 8-bit raster in place; its original quantization
is preserved, so low-alpha straight RGB need not reproduce pre-association values.
No public signatures, ABI epoch 1, library schema 6, existing goldens or budgets change.
Independent before/after evidence is recorded in `validation/2026-10-20-audit-fixes.json`.

## 3.40.0 bounded chapter reading

New chapter options/stats and pager query functions are additive. Existing public record layouts and functions retain ABI1; schema6 is unchanged. The publication is retained, and ordinary pager font/callback ownership applies. Full document snapshot pointers keep their original lifetime. See `docs/WP6-BOUNDED-READER.md` and installed `examples/window.c`.
