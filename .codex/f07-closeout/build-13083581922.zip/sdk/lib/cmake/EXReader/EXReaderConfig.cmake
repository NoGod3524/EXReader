
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
set(EXReader_VERSION "3.42.0")
set(EXReader_ABI_VERSION 1)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderDependencies.cmake")
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderTargets.cmake")
foreach(component core pdf pdf_edit audio library textindex)
  if(TARGET EXReader::exr_${component})
    set(EXReader_${component}_FOUND TRUE)
    get_target_property(EXReader_${component}_VERSION EXReader::exr_${component} EXR_COMPONENT_VERSION)
  else()
    set(EXReader_${component}_FOUND FALSE)
  endif()
endforeach()
check_required_components(EXReader)
