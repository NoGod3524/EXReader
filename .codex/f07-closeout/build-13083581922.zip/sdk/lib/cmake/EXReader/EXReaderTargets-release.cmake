#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReader::exreader" for configuration "Release"
set_property(TARGET EXReader::exreader APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exreader PROPERTIES
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexreader.3.42.0.dylib"
  IMPORTED_SONAME_RELEASE "@rpath/libexreader.1.dylib"
  )

list(APPEND _cmake_import_check_targets EXReader::exreader )
list(APPEND _cmake_import_check_files_for_EXReader::exreader "${_IMPORT_PREFIX}/lib/libexreader.3.42.0.dylib" )

# Import target "EXReader::exr_base" for configuration "Release"
set_property(TARGET EXReader::exr_base APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_base PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_base.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_base )
list(APPEND _cmake_import_check_files_for_EXReader::exr_base "${_IMPORT_PREFIX}/lib/libexr_base.a" )

# Import target "EXReader::exr_graphics" for configuration "Release"
set_property(TARGET EXReader::exr_graphics APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_graphics PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_graphics.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_graphics )
list(APPEND _cmake_import_check_files_for_EXReader::exr_graphics "${_IMPORT_PREFIX}/lib/libexr_graphics.a" )

# Import target "EXReader::exr_text" for configuration "Release"
set_property(TARGET EXReader::exr_text APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_text PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_text.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_text )
list(APPEND _cmake_import_check_files_for_EXReader::exr_text "${_IMPORT_PREFIX}/lib/libexr_text.a" )

# Import target "EXReader::exr_doc" for configuration "Release"
set_property(TARGET EXReader::exr_doc APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_doc PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_doc.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_doc )
list(APPEND _cmake_import_check_files_for_EXReader::exr_doc "${_IMPORT_PREFIX}/lib/libexr_doc.a" )

# Import target "EXReader::exr_formats" for configuration "Release"
set_property(TARGET EXReader::exr_formats APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_formats PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_formats.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_formats )
list(APPEND _cmake_import_check_files_for_EXReader::exr_formats "${_IMPORT_PREFIX}/lib/libexr_formats.a" )

# Import target "EXReader::exr_layout" for configuration "Release"
set_property(TARGET EXReader::exr_layout APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_layout PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_layout.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_layout )
list(APPEND _cmake_import_check_files_for_EXReader::exr_layout "${_IMPORT_PREFIX}/lib/libexr_layout.a" )

# Import target "EXReader::exr_render" for configuration "Release"
set_property(TARGET EXReader::exr_render APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_render PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_render.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_render )
list(APPEND _cmake_import_check_files_for_EXReader::exr_render "${_IMPORT_PREFIX}/lib/libexr_render.a" )

# Import target "EXReader::exr_pdf" for configuration "Release"
set_property(TARGET EXReader::exr_pdf APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_pdf PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_pdf.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_pdf )
list(APPEND _cmake_import_check_files_for_EXReader::exr_pdf "${_IMPORT_PREFIX}/lib/libexr_pdf.a" )

# Import target "EXReader::exr_pdf_edit" for configuration "Release"
set_property(TARGET EXReader::exr_pdf_edit APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_pdf_edit PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_pdf_edit.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_pdf_edit )
list(APPEND _cmake_import_check_files_for_EXReader::exr_pdf_edit "${_IMPORT_PREFIX}/lib/libexr_pdf_edit.a" )

# Import target "EXReader::exr_audio" for configuration "Release"
set_property(TARGET EXReader::exr_audio APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_audio PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_audio.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_audio )
list(APPEND _cmake_import_check_files_for_EXReader::exr_audio "${_IMPORT_PREFIX}/lib/libexr_audio.a" )

# Import target "EXReader::exr_library" for configuration "Release"
set_property(TARGET EXReader::exr_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_library PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_library.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_library )
list(APPEND _cmake_import_check_files_for_EXReader::exr_library "${_IMPORT_PREFIX}/lib/libexr_library.a" )

# Import target "EXReader::exr_textindex" for configuration "Release"
set_property(TARGET EXReader::exr_textindex APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReader::exr_textindex PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_textindex.a"
  )

list(APPEND _cmake_import_check_targets EXReader::exr_textindex )
list(APPEND _cmake_import_check_files_for_EXReader::exr_textindex "${_IMPORT_PREFIX}/lib/libexr_textindex.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
