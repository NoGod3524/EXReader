
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderSyncConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(EXReaderRevisions 0.3.0 EXACT CONFIG)
find_dependency(EXReaderWebDAV 0.2.0 EXACT CONFIG)
if()
  set(_sync_hash_prefix "${READER_ORIGINAL_HASH_PREFIX}")
  set(_sync_hash_env "$ENV{EXREADER_ORIGINAL_HASH_PREFIX}")
  if(NOT _sync_hash_prefix)
    set(_sync_hash_prefix "${_sync_hash_env}")
  endif()
  if(NOT IS_ABSOLUTE "${_sync_hash_prefix}" OR NOT IS_DIRECTORY "${_sync_hash_prefix}")
    message(FATAL_ERROR "Sync requires an explicit installed OPDSHash prefix")
  endif()
  file(REAL_PATH "${_sync_hash_prefix}" _sync_hash_real)
  if(NOT "${_sync_hash_prefix}" STREQUAL "${_sync_hash_real}")
    message(FATAL_ERROR "Sync hash prefix must be canonical")
  endif()
  if(_sync_hash_env)
    file(REAL_PATH "${_sync_hash_env}" _sync_hash_env_real)
    if(NOT IS_ABSOLUTE "${_sync_hash_env}" OR NOT "${_sync_hash_env}" STREQUAL "${_sync_hash_env_real}" OR
        NOT "${_sync_hash_env_real}" STREQUAL "${_sync_hash_real}")
      message(FATAL_ERROR "Conflicting Sync hash prefix selectors")
    endif()
  endif()
  set(_sync_hash_config "${_sync_hash_real}/lib/cmake/EXReaderOPDSHash")
  if(DEFINED EXReaderOPDSHash_DIR AND NOT "${EXReaderOPDSHash_DIR}" STREQUAL "${_sync_hash_config}")
    message(FATAL_ERROR "Foreign cached Sync OPDSHash package directory")
  endif()
  find_dependency(EXReaderOPDSHash 0.1.0 EXACT CONFIG REQUIRED
    PATHS "${_sync_hash_config}" NO_DEFAULT_PATH NO_CMAKE_FIND_ROOT_PATH)
  if(NOT "${EXReaderOPDSHash_DIR}" STREQUAL "${_sync_hash_config}")
    message(FATAL_ERROR "Sync hash discovery escaped its selected prefix")
  endif()
  exreader_opds_hash_validate("${_sync_hash_real}")
endif()
if(NOT WIN32 AND NOT APPLE AND NOT ANDROID)
  find_dependency(OpenSSL COMPONENTS Crypto)
endif()

include("${CMAKE_CURRENT_LIST_DIR}/EXReaderSyncTargets.cmake")

foreach(_raw_target EXReaderRevisions::reader_revisions EXReaderSync::reader_sync)
  get_target_property(_raw_dependency_defs ${_raw_target} INTERFACE_COMPILE_DEFINITIONS)
  if(OFF)
    if(NOT "EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _raw_dependency_defs)
      message(FATAL_ERROR "Exact imported target belongs to the legacy capability family")
    endif()
  else()
    if("EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _raw_dependency_defs)
      message(FATAL_ERROR "Legacy imported target cannot be replaced by a raw candidate")
    endif()
  endif()
endforeach()

if(OFF)
  _exr_raw_guard_target(EXReaderRevisions::reader_revisions "${EXReaderRevisions_DIR}"
    reader_revisions.h READER_REVISIONS_VERSION 0.4.0 TRUE)
  _exr_raw_guard_target(EXReaderSync::reader_sync "${CMAKE_CURRENT_LIST_DIR}"
    reader_sync.h READER_SYNC_VERSION 0.2.0 TRUE)
endif()
