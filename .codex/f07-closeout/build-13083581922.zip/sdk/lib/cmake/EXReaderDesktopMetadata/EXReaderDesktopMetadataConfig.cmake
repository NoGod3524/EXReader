
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderDesktopMetadataConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(EXReaderCommands 0.1.0 EXACT CONFIG)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderDesktopMetadataTargets.cmake")
get_target_property(_metadata_command_defs EXReaderCommands::reader_commands INTERFACE_COMPILE_DEFINITIONS)
if(OFF)
  if(NOT "EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _metadata_command_defs)
    message(FATAL_ERROR "Raw metadata cannot consume legacy commands")
  endif()
  _exr_raw_guard_target(EXReaderCommands::reader_commands "${EXReaderCommands_DIR}"
    reader_commands.h READER_COMMANDS_VERSION 0.2.0 TRUE)
  _exr_raw_guard_target(EXReaderDesktopMetadata::reader_desktop_metadata "${CMAKE_CURRENT_LIST_DIR}"
    reader_metadata.h READER_METADATA_VERSION 0.2.0 TRUE)
else()
  if("EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _metadata_command_defs)
    message(FATAL_ERROR "Legacy metadata cannot consume raw commands")
  endif()
endif()
