
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderReadingStateConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(EXReaderRevisions 0.3.0 EXACT CONFIG)
find_dependency(EXReader 3.42.0 EXACT CONFIG COMPONENTS core library)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderReadingStateTargets.cmake")

# RAW-CANDIDATE ORIGIN GUARD: append-only; never changes imported targets.
if(OFF)
  _exr_raw_guard_target(EXReaderRevisions::reader_revisions "${EXReaderRevisions_DIR}"
    reader_revisions.h READER_REVISIONS_VERSION 0.4.0 TRUE)
  foreach(_sdk_target EXReader::exr_core EXReader::exr_library)
    _exr_raw_guard_target("${_sdk_target}" "${EXReader_DIR}" exr/base.h EXR_VERSION 3.42.0 FALSE)
  endforeach()
  if(TARGET EXReader::exreader)
    _exr_raw_guard_target(EXReader::exreader "${EXReader_DIR}" exr/base.h EXR_VERSION 3.42.0 FALSE)
  endif()
  _exr_raw_guard_target(EXReaderReadingState::reader_reading_state_codec "${CMAKE_CURRENT_LIST_DIR}"
    reader_reading_state.h READER_READING_STATE_VERSION 0.2.0 TRUE)
  _exr_raw_guard_target(EXReaderReadingState::reader_reading_state "${CMAKE_CURRENT_LIST_DIR}"
    reader_reading_state.h READER_READING_STATE_VERSION 0.2.0 FALSE)
endif()

if(OFF)
  _exr_public_boundary_guard(EXReaderRevisions::reader_revisions "${EXReaderRevisions_DIR}"
    reader_selector_bytes_v1.h READER_REV_SELECTOR_BYTES_API_VERSION EXR_READER_PUBLIC_SELECTOR_BYTES_V1)
  _exr_public_boundary_guard(EXReaderReadingState::reader_reading_state_codec "${CMAKE_CURRENT_LIST_DIR}"
    reader_reading_state_retained_raw_v1.h READER_RS_RETAINED_RAW_API_VERSION EXR_READER_PUBLIC_RETAINED_RAW_V1)
endif()
