#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderRevisions::reader_revisions" for configuration "Release"
set_property(TARGET EXReaderRevisions::reader_revisions APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderRevisions::reader_revisions PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_revisions.a"
  )

list(APPEND _cmake_import_check_targets EXReaderRevisions::reader_revisions )
list(APPEND _cmake_import_check_files_for_EXReaderRevisions::reader_revisions "${_IMPORT_PREFIX}/lib/libreader_revisions.a" )

# Import target "EXReaderRevisions::reader_revision_hash" for configuration "Release"
set_property(TARGET EXReaderRevisions::reader_revision_hash APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderRevisions::reader_revision_hash PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_revision_hash.a"
  )

list(APPEND _cmake_import_check_targets EXReaderRevisions::reader_revision_hash )
list(APPEND _cmake_import_check_files_for_EXReaderRevisions::reader_revision_hash "${_IMPORT_PREFIX}/lib/libreader_revision_hash.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
