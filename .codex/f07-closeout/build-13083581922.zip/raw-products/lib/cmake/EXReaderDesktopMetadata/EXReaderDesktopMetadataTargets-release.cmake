#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderDesktopMetadata::reader_desktop_metadata" for configuration "Release"
set_property(TARGET EXReaderDesktopMetadata::reader_desktop_metadata APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderDesktopMetadata::reader_desktop_metadata PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_desktop_metadata.a"
  )

list(APPEND _cmake_import_check_targets EXReaderDesktopMetadata::reader_desktop_metadata )
list(APPEND _cmake_import_check_files_for_EXReaderDesktopMetadata::reader_desktop_metadata "${_IMPORT_PREFIX}/lib/libreader_desktop_metadata.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
