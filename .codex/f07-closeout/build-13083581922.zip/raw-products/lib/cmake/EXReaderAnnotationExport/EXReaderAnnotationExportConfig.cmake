
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderAnnotationExportConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(EXReaderRevisions 0.4.0 EXACT CONFIG)
find_dependency(EXReaderReadingState 0.2.0 EXACT CONFIG)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderAnnotationExportTargets.cmake")

# RAW-CANDIDATE ORIGIN GUARD: append-only; never changes imported targets.
if(ON)
  _exr_raw_guard_target(EXReaderAnnotationExport::reader_annotation_export "${CMAKE_CURRENT_LIST_DIR}"
    reader_annotation_export_raw3.h READER_ANNOTATION_EXPORT_RAW3_VERSION 0.2.0 TRUE)
endif()

if(ON)
  _exr_public_boundary_guard(EXReaderRevisions::reader_revisions "${EXReaderRevisions_DIR}"
    reader_selector_bytes_v1.h READER_REV_SELECTOR_BYTES_API_VERSION EXR_READER_PUBLIC_SELECTOR_BYTES_V1)
  _exr_public_boundary_guard(EXReaderReadingState::reader_reading_state_codec "${EXReaderReadingState_DIR}"
    reader_reading_state_retained_raw_v1.h READER_RS_RETAINED_RAW_API_VERSION EXR_READER_PUBLIC_RETAINED_RAW_V1)
endif()
