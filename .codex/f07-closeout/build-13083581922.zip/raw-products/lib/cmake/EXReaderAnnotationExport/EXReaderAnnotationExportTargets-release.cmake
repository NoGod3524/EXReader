#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderAnnotationExport::reader_annotation_export" for configuration "Release"
set_property(TARGET EXReaderAnnotationExport::reader_annotation_export APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderAnnotationExport::reader_annotation_export PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_annotation_export.a"
  )

list(APPEND _cmake_import_check_targets EXReaderAnnotationExport::reader_annotation_export )
list(APPEND _cmake_import_check_files_for_EXReaderAnnotationExport::reader_annotation_export "${_IMPORT_PREFIX}/lib/libreader_annotation_export.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
