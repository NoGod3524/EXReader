
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderWebDAVObservedConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
get_filename_component(_observed_webdav_dir "${CMAKE_CURRENT_LIST_DIR}/../EXReaderWebDAV" REALPATH)
if(TARGET EXReaderWebDAV::exr_webdav)
  get_filename_component(_observed_existing_dir "${EXReaderWebDAV_DIR}" REALPATH)
  if(NOT _observed_existing_dir STREQUAL _observed_webdav_dir)
    message(FATAL_ERROR "Observed capability and loaded WebDAV package must come from the same installation")
  endif()
endif()
find_dependency(EXReaderWebDAV 0.2.0 EXACT CONFIG PATHS "${_observed_webdav_dir}" NO_DEFAULT_PATH)
get_filename_component(_observed_loaded_dir "${EXReaderWebDAV_DIR}" REALPATH)
if(NOT _observed_loaded_dir STREQUAL _observed_webdav_dir)
  message(FATAL_ERROR "Observed capability and WebDAV package must come from the same installation")
endif()
