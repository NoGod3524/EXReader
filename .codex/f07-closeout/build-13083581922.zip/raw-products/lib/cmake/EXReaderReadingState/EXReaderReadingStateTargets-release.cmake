#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderReadingState::reader_reading_state" for configuration "Release"
set_property(TARGET EXReaderReadingState::reader_reading_state APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderReadingState::reader_reading_state PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_reading_state.a"
  )

list(APPEND _cmake_import_check_targets EXReaderReadingState::reader_reading_state )
list(APPEND _cmake_import_check_files_for_EXReaderReadingState::reader_reading_state "${_IMPORT_PREFIX}/lib/libreader_reading_state.a" )

# Import target "EXReaderReadingState::reader_reading_state_codec" for configuration "Release"
set_property(TARGET EXReaderReadingState::reader_reading_state_codec APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderReadingState::reader_reading_state_codec PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_reading_state_codec.a"
  )

list(APPEND _cmake_import_check_targets EXReaderReadingState::reader_reading_state_codec )
list(APPEND _cmake_import_check_files_for_EXReaderReadingState::reader_reading_state_codec "${_IMPORT_PREFIX}/lib/libreader_reading_state_codec.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
