#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderFontLibrary::reader_font_library" for configuration "Release"
set_property(TARGET EXReaderFontLibrary::reader_font_library APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderFontLibrary::reader_font_library PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_font_library.a"
  )

list(APPEND _cmake_import_check_targets EXReaderFontLibrary::reader_font_library )
list(APPEND _cmake_import_check_files_for_EXReaderFontLibrary::reader_font_library "${_IMPORT_PREFIX}/lib/libreader_font_library.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
