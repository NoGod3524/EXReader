
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderFontLibraryConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
# Exactly the SDK this package was built against; no second version/provider.
find_dependency(EXReader 3.42.0 EXACT CONFIG COMPONENTS core)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderSdkTargetGuard.cmake")
_exr_sdk_target_provenance(EXReader::exr_core "${EXReader_DIR}" "3.42.0")
find_dependency(Threads)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderFontLibraryTargets.cmake")
