#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderAnnotationImport::reader_annotation_import" for configuration "Release"
set_property(TARGET EXReaderAnnotationImport::reader_annotation_import APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderAnnotationImport::reader_annotation_import PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_annotation_import.a"
  )

list(APPEND _cmake_import_check_targets EXReaderAnnotationImport::reader_annotation_import )
list(APPEND _cmake_import_check_files_for_EXReaderAnnotationImport::reader_annotation_import "${_IMPORT_PREFIX}/lib/libreader_annotation_import.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
