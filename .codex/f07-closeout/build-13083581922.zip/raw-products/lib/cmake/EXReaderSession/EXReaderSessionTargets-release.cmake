#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderSession::reader_session" for configuration "Release"
set_property(TARGET EXReaderSession::reader_session APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderSession::reader_session PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_session.a"
  )

list(APPEND _cmake_import_check_targets EXReaderSession::reader_session )
list(APPEND _cmake_import_check_files_for_EXReaderSession::reader_session "${_IMPORT_PREFIX}/lib/libreader_session.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
