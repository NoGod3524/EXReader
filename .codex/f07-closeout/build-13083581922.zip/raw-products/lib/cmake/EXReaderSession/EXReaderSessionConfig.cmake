
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderSessionConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(EXReaderSync 0.2.0 EXACT CONFIG)
find_dependency(Threads)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderSessionTargets.cmake")

foreach(_raw_target EXReaderSync::reader_sync EXReaderSession::reader_session)
  get_target_property(_raw_dependency_defs ${_raw_target} INTERFACE_COMPILE_DEFINITIONS)
  if(ON)
    if(NOT "EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _raw_dependency_defs)
      message(FATAL_ERROR "Exact imported target belongs to the legacy capability family")
    endif()

  else()
    if("EXR_READER_SELECTOR_BYTES_CANDIDATE=1" IN_LIST _raw_dependency_defs)
      message(FATAL_ERROR "Legacy imported target cannot be replaced by a raw candidate")
    endif()
  endif()
endforeach()

if(ON)
  _exr_raw_guard_target(EXReaderSync::reader_sync "${EXReaderSync_DIR}"
    reader_sync.h READER_SYNC_VERSION 0.2.0 TRUE)
  _exr_raw_guard_target(EXReaderSession::reader_session "${CMAKE_CURRENT_LIST_DIR}"
    reader_session.h READER_SESSION_VERSION 0.2.0 TRUE)
endif()
