#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderProductCatalog::reader_catalog" for configuration "Release"
set_property(TARGET EXReaderProductCatalog::reader_catalog APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderProductCatalog::reader_catalog PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_catalog.a"
  )

list(APPEND _cmake_import_check_targets EXReaderProductCatalog::reader_catalog )
list(APPEND _cmake_import_check_files_for_EXReaderProductCatalog::reader_catalog "${_IMPORT_PREFIX}/lib/libreader_catalog.a" )

# Import target "EXReaderProductCatalog::reader_catalog_sqlite" for configuration "Release"
set_property(TARGET EXReaderProductCatalog::reader_catalog_sqlite APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderProductCatalog::reader_catalog_sqlite PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_catalog_sqlite.a"
  )

list(APPEND _cmake_import_check_targets EXReaderProductCatalog::reader_catalog_sqlite )
list(APPEND _cmake_import_check_files_for_EXReaderProductCatalog::reader_catalog_sqlite "${_IMPORT_PREFIX}/lib/libreader_catalog_sqlite.a" )

# Import target "EXReaderProductCatalog::reader_original_import" for configuration "Release"
set_property(TARGET EXReaderProductCatalog::reader_original_import APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderProductCatalog::reader_original_import PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_original_import.a"
  )

list(APPEND _cmake_import_check_targets EXReaderProductCatalog::reader_original_import )
list(APPEND _cmake_import_check_files_for_EXReaderProductCatalog::reader_original_import "${_IMPORT_PREFIX}/lib/libreader_original_import.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
