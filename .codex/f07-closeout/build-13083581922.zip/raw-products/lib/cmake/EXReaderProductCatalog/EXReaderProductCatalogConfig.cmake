
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderProductCatalogConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(Threads)
# Exact dependency hook; independent of old builders' CMAKE_PREFIX_PATH overrides.
set(_hash_prefix "${READER_ORIGINAL_HASH_PREFIX}")
set(_hash_env "$ENV{EXREADER_ORIGINAL_HASH_PREFIX}")
if(NOT _hash_prefix)
  set(_hash_prefix "${_hash_env}")
endif()
if(NOT IS_ABSOLUTE "${_hash_prefix}" OR NOT IS_DIRECTORY "${_hash_prefix}")
  message(FATAL_ERROR "Set READER_ORIGINAL_HASH_PREFIX or EXREADER_ORIGINAL_HASH_PREFIX to the installed OPDSHash prefix")
endif()
file(REAL_PATH "${_hash_prefix}" _hash_real)
if(NOT "${_hash_prefix}" STREQUAL "${_hash_real}")
  message(FATAL_ERROR "Original hash prefix must be canonical")
endif()
if(_hash_env)
  file(REAL_PATH "${_hash_env}" _hash_env_real)
  if(NOT IS_ABSOLUTE "${_hash_env}" OR NOT "${_hash_env}" STREQUAL "${_hash_env_real}" OR
      NOT "${_hash_env_real}" STREQUAL "${_hash_real}")
    message(FATAL_ERROR "Conflicting original hash prefix selectors")
  endif()
endif()
set(_hash_config "${_hash_real}/lib/cmake/EXReaderOPDSHash")
if(DEFINED EXReaderOPDSHash_DIR AND NOT "${EXReaderOPDSHash_DIR}" STREQUAL "${_hash_config}")
  message(FATAL_ERROR "Foreign cached OPDSHash package directory")
endif()
find_dependency(EXReaderOPDSHash 0.1.0 EXACT CONFIG REQUIRED
  PATHS "${_hash_config}" NO_DEFAULT_PATH NO_CMAKE_FIND_ROOT_PATH)
if(NOT "${EXReaderOPDSHash_DIR}" STREQUAL "${_hash_config}")
  message(FATAL_ERROR "Original hash package discovery escaped the selected prefix")
endif()
exreader_opds_hash_validate("${_hash_real}")
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderProductCatalogTargets.cmake")
