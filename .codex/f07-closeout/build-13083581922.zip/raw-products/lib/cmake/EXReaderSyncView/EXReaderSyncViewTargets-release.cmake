#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderSyncView::reader_sync_view" for configuration "Release"
set_property(TARGET EXReaderSyncView::reader_sync_view APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderSyncView::reader_sync_view PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_sync_view.a"
  )

list(APPEND _cmake_import_check_targets EXReaderSyncView::reader_sync_view )
list(APPEND _cmake_import_check_files_for_EXReaderSyncView::reader_sync_view "${_IMPORT_PREFIX}/lib/libreader_sync_view.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
