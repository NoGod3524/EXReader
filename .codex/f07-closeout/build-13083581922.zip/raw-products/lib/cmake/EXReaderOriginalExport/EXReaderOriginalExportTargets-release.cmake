#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderOriginalExport::reader_original_export" for configuration "Release"
set_property(TARGET EXReaderOriginalExport::reader_original_export APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderOriginalExport::reader_original_export PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_original_export.a"
  )

list(APPEND _cmake_import_check_targets EXReaderOriginalExport::reader_original_export )
list(APPEND _cmake_import_check_files_for_EXReaderOriginalExport::reader_original_export "${_IMPORT_PREFIX}/lib/libreader_original_export.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
