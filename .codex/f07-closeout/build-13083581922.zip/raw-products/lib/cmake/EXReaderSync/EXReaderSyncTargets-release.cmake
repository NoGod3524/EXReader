#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderSync::reader_sync" for configuration "Release"
set_property(TARGET EXReaderSync::reader_sync APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderSync::reader_sync PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_sync.a"
  )

list(APPEND _cmake_import_check_targets EXReaderSync::reader_sync )
list(APPEND _cmake_import_check_files_for_EXReaderSync::reader_sync "${_IMPORT_PREFIX}/lib/libreader_sync.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
