#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderReadingCommands::reader_reading_commands" for configuration "Release"
set_property(TARGET EXReaderReadingCommands::reader_reading_commands APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderReadingCommands::reader_reading_commands PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_reading_commands.a"
  )

list(APPEND _cmake_import_check_targets EXReaderReadingCommands::reader_reading_commands )
list(APPEND _cmake_import_check_files_for_EXReaderReadingCommands::reader_reading_commands "${_IMPORT_PREFIX}/lib/libreader_reading_commands.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
