#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderSearch::reader_search" for configuration "Release"
set_property(TARGET EXReaderSearch::reader_search APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderSearch::reader_search PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_search.a"
  )

list(APPEND _cmake_import_check_targets EXReaderSearch::reader_search )
list(APPEND _cmake_import_check_files_for_EXReaderSearch::reader_search "${_IMPORT_PREFIX}/lib/libreader_search.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
