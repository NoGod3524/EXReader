#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderNavigation::reader_navigation" for configuration "Release"
set_property(TARGET EXReaderNavigation::reader_navigation APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderNavigation::reader_navigation PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_navigation.a"
  )

list(APPEND _cmake_import_check_targets EXReaderNavigation::reader_navigation )
list(APPEND _cmake_import_check_files_for_EXReaderNavigation::reader_navigation "${_IMPORT_PREFIX}/lib/libreader_navigation.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
