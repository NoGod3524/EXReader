#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderJumpHistory::reader_jump_history" for configuration "Release"
set_property(TARGET EXReaderJumpHistory::reader_jump_history APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderJumpHistory::reader_jump_history PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_jump_history.a"
  )

list(APPEND _cmake_import_check_targets EXReaderJumpHistory::reader_jump_history )
list(APPEND _cmake_import_check_files_for_EXReaderJumpHistory::reader_jump_history "${_IMPORT_PREFIX}/lib/libreader_jump_history.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
