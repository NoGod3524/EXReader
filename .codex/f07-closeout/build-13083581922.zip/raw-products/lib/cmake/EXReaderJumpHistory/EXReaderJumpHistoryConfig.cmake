
####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was EXReaderJumpHistoryConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

macro(check_required_components _NAME)
  foreach(comp ${${_NAME}_FIND_COMPONENTS})
    if(NOT ${_NAME}_${comp}_FOUND)
      if(${_NAME}_FIND_REQUIRED_${comp})
        set(${_NAME}_FOUND FALSE)
      endif()
    endif()
  endforeach()
endmacro()

####################################################################################
include(CMakeFindDependencyMacro)
find_dependency(Threads)
find_dependency(EXReaderReadingState 0.2.0 EXACT CONFIG)
include("${CMAKE_CURRENT_LIST_DIR}/EXReaderJumpHistoryTargets.cmake")

# RAW-CANDIDATE ORIGIN GUARD: append-only; never changes imported targets.
if(ON)
  _exr_raw_guard_target(EXReaderReadingState::reader_reading_state_codec "${EXReaderReadingState_DIR}"
    reader_reading_state.h READER_READING_STATE_VERSION 0.2.0 TRUE)
  _exr_raw_guard_target(EXReaderReadingState::reader_reading_state "${EXReaderReadingState_DIR}"
    reader_reading_state.h READER_READING_STATE_VERSION 0.2.0 FALSE)
  _exr_raw_guard_target(EXReaderJumpHistory::reader_jump_history "${CMAKE_CURRENT_LIST_DIR}"
    reader_jump_history.h READER_JH_INSTALL_VERSION 0.2.0 TRUE)
endif()
