#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderCredentials::exr_credentials" for configuration "Release"
set_property(TARGET EXReaderCredentials::exr_credentials APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderCredentials::exr_credentials PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_credentials.a"
  )

list(APPEND _cmake_import_check_targets EXReaderCredentials::exr_credentials )
list(APPEND _cmake_import_check_files_for_EXReaderCredentials::exr_credentials "${_IMPORT_PREFIX}/lib/libexr_credentials.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
