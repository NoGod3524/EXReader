#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderWebDAV::exr_webdav" for configuration "Release"
set_property(TARGET EXReaderWebDAV::exr_webdav APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderWebDAV::exr_webdav PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX;OBJCXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libexr_webdav.a"
  )

list(APPEND _cmake_import_check_targets EXReaderWebDAV::exr_webdav )
list(APPEND _cmake_import_check_files_for_EXReaderWebDAV::exr_webdav "${_IMPORT_PREFIX}/lib/libexr_webdav.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
