#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderAnnotationView::reader_annotation_view" for configuration "Release"
set_property(TARGET EXReaderAnnotationView::reader_annotation_view APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderAnnotationView::reader_annotation_view PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "CXX"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libreader_annotation_view.a"
  )

list(APPEND _cmake_import_check_targets EXReaderAnnotationView::reader_annotation_view )
list(APPEND _cmake_import_check_files_for_EXReaderAnnotationView::reader_annotation_view "${_IMPORT_PREFIX}/lib/libreader_annotation_view.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
