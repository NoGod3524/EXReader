#----------------------------------------------------------------
# Generated CMake target import file for configuration "Release".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "EXReaderOPDSHash::opds_sha256_stream" for configuration "Release"
set_property(TARGET EXReaderOPDSHash::opds_sha256_stream APPEND PROPERTY IMPORTED_CONFIGURATIONS RELEASE)
set_target_properties(EXReaderOPDSHash::opds_sha256_stream PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_RELEASE "C"
  IMPORTED_LOCATION_RELEASE "${_IMPORT_PREFIX}/lib/libopds_sha256_stream.a"
  )

list(APPEND _cmake_import_check_targets EXReaderOPDSHash::opds_sha256_stream )
list(APPEND _cmake_import_check_files_for_EXReaderOPDSHash::opds_sha256_stream "${_IMPORT_PREFIX}/lib/libopds_sha256_stream.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
